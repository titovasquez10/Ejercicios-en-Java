/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package elevacionnumero;

import javax.swing.JOptionPane;
/**
 *
 * @author desarrollo
 */
public class ElevacionNumero {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        int x;
        int resultado = 0;
        int x1;
        int y;
        
        x = Integer.valueOf(JOptionPane.showInputDialog("Ingrese un Numero"));
        y = Integer.valueOf(JOptionPane.showInputDialog("Digite la potencia"));
        
        x1=x;
        for(int i= 0; i < y-1; i++)
        {
            x*=x1;
        }
        System.out.print("el numero es "+x);
    }

    
}
