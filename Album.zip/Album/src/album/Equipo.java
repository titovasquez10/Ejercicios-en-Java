/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package album;


public class Equipo {
  
//Atributos
private String nombree;
private int anioFundacion;
private String tecnico;

//Declaracion de Matrix 
final int FILAS = 4, COLUMNAS =3;

//Llamado a la clase Jugador
private Jugador jugadores[][];

//Metodos:

//Metodo Constructor
public Equipo(String unaNombre, int unAnioFundacion, String unTecnico)
{
 nombree = unaNombre;
 anioFundacion = unAnioFundacion;
 tecnico = unTecnico;
 
 //Inicializacion de la matrix (Arreglo)
 jugadores = new Jugador [FILAS][COLUMNAS];
}        

//Metodo agragar jugador
public void AgregarJugador(Jugador pJugador)
{
    boolean encontrado = false;
    
    for(int i = 0; i < FILAS && !encontrado; i++)
    {
        for(int j = 0; j < COLUMNAS && !encontrado; j++)
        {
            if(jugadores[i][j] == null)
            {
                jugadores[i][j] = pJugador;
                encontrado = true;
            }
        }
    }
}        


//Metodo consulta
public String darNombree()
{
  return nombree;  
}        

public int darAnioFundacion()
{
    return anioFundacion;
}        

public String darTecnico()
{
    return tecnico;
}        



}
