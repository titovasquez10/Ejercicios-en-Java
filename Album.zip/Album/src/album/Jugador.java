/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package album;

/**
 *
 * @author desarrollo
 */
public class Jugador {

//Atributos    
private String nombre;
private double estatura;
private double peso;
private double posicion;
private String fechaNac ;
private String club;

//Metodo Constructor
public Jugador(String unNombre, double unaEstatura, double elPeso, double laPosicion, String unaFechaNac, String unClub)
{
    nombre = unNombre;
    estatura = unaEstatura;
    peso = elPeso;
    posicion = laPosicion;
    fechaNac = unaFechaNac;
    club = unClub;
}

//Metodo Consulta
public String darNombre()
{
    return nombre;
}

public double darEstatura()
{
    return estatura;
}        

public double darPeso()
{
    return peso;
}        

public double darPosicion()
{
    return posicion;
}        

public String darFechaNac()
{
    return fechaNac;
}        

public String darClub()
{
    return club;
}        


}
