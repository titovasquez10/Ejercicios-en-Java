package album;

import java.io.*;


public class Album {

    private int anioAlbum;
    final int NUM_EQUIPOS = 32;
    private Equipo equipos[];
    
    //Construtora
    public Album(int pAnio)
    {
     anioAlbum = pAnio;   
    
     equipos = new Equipo[NUM_EQUIPOS];
    }
    
    /***
     * El metodo carga informacion de un equipo desde un acrchivo de texo
     * @param rutaDatos no debe ser vacio, debe apuntar a un archivo de texto 
     */
    public void CargarEquipo(String rutaDatos)
    {
        try{
    BufferedReader br = new BufferedReader(new FileReader(rutaDatos));    
        
        //Leer datos del equipo
        String nombreEquipo = br.readLine();
        String tecnico = br.readLine();
        int anioFundacion = Integer.parseInt(br.readLine());
        br.close();
        
        //Crea Equipo
        Equipo nuevoEquipo = new Equipo(nombreEquipo, anioFundacion, tecnico);
        AgregarEquipo(nuevoEquipo);
        }
        catch(FileNotFoundException e){
                e.printStackTrace();
        }
        catch (IOException e){
                e.printStackTrace();
              }        
       }
        
    
    /***
     * Agrega un equipo a la lista de equipos
     * @param pEquipo El quipo que se va agregar. De ser ! = null
     */
    
    //Recore el arreglo hasta que encuentre una casilla  
    public void AgregarEquipo(Equipo pEquipo)
    {
    boolean encontrado = false;
    
    for(int t = 0; t < NUM_EQUIPOS && !encontrado; t++)
    {
            if(equipos[t] == null)
            {
                equipos[t] = pEquipo;
                encontrado = true;
            }
    }
        
    }
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
    Album miAlbum = new Album(2018);
    miAlbum.CargarEquipo("./datos/datosAlemania.txt");
        
        
    }
    
}
