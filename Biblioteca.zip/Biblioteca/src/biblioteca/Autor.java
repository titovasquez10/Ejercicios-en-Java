/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package biblioteca;

/**
 *
 * @author desarrollo
 */
public class Autor {
    
    //Atributos
    String nombre;
    String nacionalidad;
    
    //Metodo
    public Autor()
    {
     nombre = "";
     nacionalidad = "";
    }
    
    public Autor(String unNombre)
    {
        nombre = unNombre;
    }
    
    public Autor(String unNombre, String unaNacionalidad)
    {
        nombre = unNombre;
        nacionalidad = unaNacionalidad;
    }
    
    
    //Metodos de consulta
   
    public String darNombre()
    {
     return nombre;   
    }
    
    public String darNacionalidad()
    {
        return nacionalidad;
    }
    
    
    //Metodos de modificacion
    public void modificarNombre(String nuevoNombre)
    {
        nombre = nuevoNombre;
    }
    
    public void modificarNacionalidad(String nuevaNacionalidad)
    {
        nacionalidad = nuevaNacionalidad;
    }
    
    
    
}
