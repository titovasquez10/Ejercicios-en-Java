/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package biblioteca;

import java.io.*;
import java.util.ArrayList;
import java.util.Properties;

/**
 *
 * @author desarrollo
 */
public class Biblioteca {
    
    ArrayList<Libro> libros;
    String propietario;
    String direccion;
    String privada;

   
    public static void main(String[] args) {
        // TODO code application logic here
        Biblioteca miBiblioteca = new Biblioteca();
    }
    
    public Biblioteca()
    {
        libros = new ArrayList<Libro>();
        
        //Carga inicial de la info:
        cargaInicialDatos();
    }
    
    private void Agregarlibro(Libro unLibro)
    {
       libros.add(unLibro);
    }        
    
    public void cargaInicialDatos()
    {
        File archivoBiblioteca = new File("./Datos/biblioteca1.properties");
     
        try{
            FileInputStream flujoDatos = new FileInputStream(archivoBiblioteca);
            
            Properties datosBiblioteca = new Properties();
            
            datosBiblioteca.load(flujoDatos);
            flujoDatos.close();
            
            String strNumerosLibros = datosBiblioteca.getProperty("biblioteca.numeroEjemplares");
            int intNumeroLibros = Integer.parseInt(strNumerosLibros);
            
            String tituloLibro, ISBNLibro, anioLibro, numAutoresLibro;
            int intAnioLibro, NumAutoresLibro;
            
            for(int i = 1; i <= intNumeroLibros; i++)
            {
              tituloLibro = datosBiblioteca.getProperty("biblioteca.libro"+i+".titulo");
              ISBNLibro = datosBiblioteca.getProperty("biblioteca.libro"+i+".ISBN");
              anioLibro = datosBiblioteca.getProperty("biblioteca.libro"+i+".anioPublicacion");
              
              intNumAutoresLibro = Integer.parseInt(datosBiblioteca.getProperty("biblioteca.libro"+i+".numAutores"));
              
              Libro nuevoLibro = new Libro(tituloLibro, ISBNLibro, intAnioLibro);
              
              for(int j = 1; j<= intNumAutoresLibro; j++)
              {
                String nombreAutor = datosBiblioteca.getProperty("biblioteca.libro.autor1.nombre"+i+".nombre");
                String nacionalidad = datosBiblioteca.getProperty("biblioteca.libro.autor1.nombre"+i+".nacionalidad");
                Autor nuevoAutor = new Autor(nombreAutor, nacionalidad);
                nuevoLibro.agregarAutor(nuevoAutor);
              }
            }
            
           } 
         catch(Exception ex)  
      {
        System.out.print("Se presento una excepcion abiendo el archivo"+ex.getMessage());
      }
      
      
    }
}
