/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package biblioteca;

import java.util.ArrayList;

public class Libro {

//Forma de definir un arreglo dinamico
ArrayList<Autor> autores;
private String titulo;
private String ISBN;
private String editorial;
private int anoPublicacion;

    public Libro()
    {
        autores = new ArrayList<Autor>();
    }
    
    public Libro(String unTitulo, String unISBN, String unaEditorial, int unAnoPublicacion)
    {
        autores = new ArrayList<Autor>();
        titulo = unTitulo;
        ISBN = unISBN;
        editorial = unaEditorial;
        anoPublicacion = unAnoPublicacion;
    }
    
    
    //Metodos de consulta:
    public String darTitulo()
    {
        return titulo;
    }
    
    public String darISBN()
    {
        return ISBN;
    }
    
    public String darEditorial()
    {
        return editorial;
    }
    
    public String darAnoPublicacion()
    {
        return titulo;
    }
    
    public ArrayList<Autor> darAutores()
    {
        return autores;
    }
    
    //Metodos de modificacion
    public void agregarAutor(Autor unAutor)
    {
        autores.add(unAutor);
    }

    
    
    
}
