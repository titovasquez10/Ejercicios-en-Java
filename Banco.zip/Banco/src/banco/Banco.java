/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package banco;

import javax.swing.*;

import javax.swing.JOptionPane;
/**
 *
 * @author desarrollo
 */
public class Banco {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
     
    double montoInicial;
    double porcentaje = 0.03;
    double totalPagar;
    double anos;
    
    montoInicial = Integer.valueOf(JOptionPane.showInputDialog("Digite el valor del monto"));
    anos = Integer.valueOf(JOptionPane.showInputDialog("Digite los años"));
    
    for(double i= 0; i < anos ;i++)
    {
    
        montoInicial += montoInicial * porcentaje;
    }
    
    totalPagar = montoInicial;
    
    JOptionPane.showMessageDialog(null,"El valor total a pagar es de:"+totalPagar);
    }
    
}    

