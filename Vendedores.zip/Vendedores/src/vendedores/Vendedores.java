/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package vendedores;

import javax.swing.JOptionPane;
/**
 *
 * @author titovasquez
 */
public class Vendedores {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
   
    int NUM_VENDEDORES = 4;
    int NUM_PRODUCTOS = 5;
    String vendedores [] = {"Vendedor_1", "Vendedor_2","Vendedor_3", "Vendedor_4",};
    int registrar[][];
    
    registrar = new int [NUM_VENDEDORES][NUM_PRODUCTOS];
    
    for(int i=0; i < NUM_VENDEDORES; i++)
    {
        for(int j=0; j < NUM_PRODUCTOS; j++)
        {
        JOptionPane.showInputDialog("Digite la cantidad de productos del",NUM_VENDEDORES);
        }    
    }
        
    }
 
}
