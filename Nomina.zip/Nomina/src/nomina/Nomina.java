/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package nomina;

import javax.swing.JOptionPane;

/**
 *
 * @author titovasquez
 */
public class Nomina {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
      
     int FILAS = 2;
     int COLUMNA = 2;
     
     String registrar[][];
     registrar = new String[FILAS][COLUMNA+1];
     
     float sueldo;
     int dias;
     
     float auxilio_de_transporte = 75000;
     
     for(int i = 0; i <FILAS; i++)
     {
         registrar[i][0] = JOptionPane.showInputDialog("Digite el nombre del Empleado");
         
         for(int j=1; j<COLUMNA; j++)
         {
          registrar[i][j] = JOptionPane.showInputDialog("Digite el suledo asignado"+registrar[i][0]);
          sueldo = Float.valueOf(registrar[i][j]);
          
          registrar[i][j]= JOptionPane.showInputDialog("Digite Dias laborados"+registrar[i][0]);
          dias = Integer.parseInt(registrar[i][j]);
         }
         
     }
     
     
     
        
        
        
    }
    
}
