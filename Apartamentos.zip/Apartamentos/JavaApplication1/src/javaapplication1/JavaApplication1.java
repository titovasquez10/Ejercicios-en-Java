/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication1;

import javax.swing.*;

import javax.swing.JOptionPane;

/**
 *
 * @author desarrollo
 */
public class JavaApplication1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
       
       int num_bloques;
       int num_pisos;
       int num_aptos = 0;
       int num_desocupados  = 0;
       float porc_desocupados;
       
      num_bloques = Integer.valueOf(JOptionPane.showInputDialog("Digite el numero de bloques"));
      
      for(int i=0; i < num_bloques; i++)
      {    
      num_pisos = Integer.valueOf(JOptionPane.showInputDialog("Digite el numero de pisos"));
      
        for(int j = 0; j < num_pisos; j++)
        {
        num_aptos = num_aptos + Integer.valueOf(JOptionPane.showInputDialog("Digite numero de Aptos"));
        
        num_desocupados = num_desocupados + Integer.valueOf(JOptionPane.showInputDialog("Digite numero de Apatos desocupados"));
      
        }    
      }
      
      porc_desocupados = num_aptos / num_desocupados;
      
      JOptionPane.showMessageDialog(null,"El % de desocupados es: "+porc_desocupados);
    //System.out.print("El porcentaje de de aptos desocupados por bloque %"+porc_desocupados);
   
    }  
    
}
