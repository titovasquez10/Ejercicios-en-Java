/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package asistenciaclases;

import javax.swing.JOptionPane;

/**
 *
 * @author desarrollo
 */
public class AsistenciaClases {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
       
    int NUM_SEMANAS = 2;
    int CANT_ESTUDIANTES = 2;
    String asistencias[][];
    asistencias = new String[CANT_ESTUDIANTES][NUM_SEMANAS+1];
    float porcentaje;
    
    
    
    for(int fila=0; fila<CANT_ESTUDIANTES; fila++)
    {
       asistencias[fila][0] = JOptionPane.showInputDialog("Digite el nombre del estudiante");
       
       for(int columna=1; columna<=NUM_SEMANAS; columna++)
       {
           asistencias[fila][columna] = JOptionPane.showInputDialog("Digite Asistencia de "+asistencias[fila][0]);
       }
    }
    
    String todas_asistencias = " ";
    
    for(int fila=0; fila<CANT_ESTUDIANTES; fila++)
    {
        for(int columna=0; columna<=NUM_SEMANAS; columna++)
        {
            todas_asistencias += asistencias[fila][columna]+",";
          
        }
        todas_asistencias+="\n";
      
    }
    JOptionPane.showMessageDialog(null,todas_asistencias);  
  
        int num_estudiante = 0;
        int num_inasistencias =0;
        num_estudiante = Integer.parseInt(JOptionPane.showInputDialog("Dijite el numero del estudiante que desea saber el promedio: "));
        for(int c= 1; c<=NUM_SEMANAS; c++)
       
        if(asistencias[num_estudiante][c] == "N")
        {
           num_inasistencias++;
        }
        
       porcentaje = (float)num_inasistencias/(float)NUM_SEMANAS; 
       
        System.out.print("El porcentaje es:"+porcentaje);
    }
   
    
}
