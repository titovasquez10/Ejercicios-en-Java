/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package agenda;

/**
 *
 * @author desarrollo
 */
public class Fecha {
    
    int dia;
    int mes;
    int anio;
    
    
     public Fecha(int elMes, int elDia, int elAnio)
     {
      dia = elAnio;
      mes = elMes;
      anio = elAnio;
     }
    
}
