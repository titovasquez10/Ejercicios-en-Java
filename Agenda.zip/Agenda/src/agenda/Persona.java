/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package agenda;

/**
 *
 * @author desarrollo
 */
public class Persona {
    
    String nombre;
    String documento;
    String telefono;
    String direccion;
    float estatura;
    String genero;
    Fecha fechaNac;
    
    public Persona(String elNombre, String elDocumento, String elTelefono, String laDireccion, String elGenero, 
                    float laEstatura, Fecha laFechanac)
    {
     nombre = elNombre;
     telefono = elTelefono;
     documento = elDocumento;
     direccion = laDireccion;
     genero = elGenero;
     estatura = laEstatura;
     fechaNac = laFechanac;
     
    
    }
}
