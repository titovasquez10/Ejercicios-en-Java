/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package agenda;

import javax.swing.JOptionPane;


/**
 *
 * @author desarrollo
 */
public class Agenda {

    /**
     * @param args the command line arguments
     */
    
    //arreglo de personas son 3
    final int NUM_PERSONAS=3;
    Persona personas[];
    
    
    public static void main(String[] args) {
        // TODO code application logic here
    }    
        
        void agregarPersonas()
        {
         String unNombre, unDocumento, unTelefono, unaDireccion, unGenero;
         float unaEstatura;
         Fecha unaFecha;
         int unDia, unMes, unAnio;
         Persona nuevaPersona;
            
            unNombre = JOptionPane.showInputDialog("Ingrese el nombre de la persona");
            unDocumento = JOptionPane.showInputDialog("Ingrese el documento");
            unTelefono = JOptionPane.showInputDialog("Ingrese el telefono");
            unaDireccion = JOptionPane.showInputDialog("Ingrese la direccion");
            unGenero = JOptionPane.showInputDialog("Ingrese el genero");
            
            //Pasar un String a un float
            unaEstatura = Float.parseFloat(JOptionPane.showInputDialog("Ingrese la estatura"));
            
            unDia = Integer.parseInt(JOptionPane.showInputDialog("Digite el dia de nacimiento"));
            unMes = Integer.parseInt(JOptionPane.showInputDialog("Digite el mes de nacimiento"));
            unAnio = Integer.parseInt(JOptionPane.showInputDialog("Digite el Año de nacimiento"));
            
            unaFecha = new Fecha(unMes, unDia, unAnio);
            
            nuevaPersona = new Persona(unNombre, unDocumento, unTelefono, unaDireccion, unGenero, unaEstatura, unaFecha);
            
        }        
                
    
    
}
