/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ecuaciones;

import javax.swing.JOptionPane;
/**
 *
 * @author desarrollo
 */
public class Ecuaciones {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
    
    int x;
    int y;
    int total1;
    int total2;
    
    x = Integer.valueOf(JOptionPane.showInputDialog("Digite el valor de X"));
    y = Integer.valueOf(JOptionPane.showInputDialog("Digite el valor de Y"));
    
    total1 = x + 3*y; 
    total2 = 2*x -5*y;
    
    if(total1 == total2)
    {
       System.out.print("Son iguales");
    }   
    else
    {
       System.out.print("no son iguales");
    }    
    
    }
    
}
