/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package parqueadero;


import java.util.Random;
import javax.swing.JOptionPane;
/**
 *
 * @author desarrollo
 */
public class Parqueadero {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
    int NUM_DIAS = 7;
    int NUM_HORAS = 24;
    String dias[] = {"Lunes", "Martes", "Miercoles", "Jueves", "Viernes", "Sabado", "Domingo"};
    int registro [][];
    registro = new int[NUM_DIAS][NUM_HORAS];
    
    Random r = new Random();
    
    for(int i=0; i<NUM_HORAS; i++)
    {
        for(int j=0; j<NUM_DIAS; j++)
        {
         registro[i][j] = r.nextInt(100);
        }     
        
    }
    
    
    
    
    
    // TODO code application logic here
    }
    
}
