/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package distanciasentreciudades;

import javax.swing.JOptionPane;

/**
 *
 * @author desarrollo
 */
public class DistanciasEntreCiudades {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
    
    final int NUM_CIUDADES = 5;
    String[] nombre_ciudades = {"Cali", "Bogotá","Medellín", "Barranquilla", "Cúcuta"};
    float[][] distancias;
    distancias = new float[NUM_CIUDADES][NUM_CIUDADES];
    float mayorDist = 0;
    float menorDist = 99999;
    String valor;
        int iMayor=0, jMayor=0;
    int iMenor=0, jMenor =0;
    
    for(int i =0; i<NUM_CIUDADES; i++)
    {
      for(int j=0; j<NUM_CIUDADES; j++)
      {
          if(i != j)
          {
            //Leer info
            valor = JOptionPane.showInputDialog("Digite la distancia entre "+nombre_ciudades[i]+ " Y " +nombre_ciudades[j]);
           //Almacenar en la matriz
            distancias[i][j] = Float.valueOf(valor);
            
            if(distancias[i][j] > mayorDist)
            {
                mayorDist = distancias[i][j];
                iMayor = i;
                jMayor = j;
            }
           
            if(distancias [i][j] < menorDist)
            {
                menorDist = distancias[i][j];
                iMenor = i;
                jMenor = j;
            }
            
          }
          else
          {
              distancias[i][j] = 0;
          }
      }
    }
    
    //Mostrar ciudades mas alejadas y cercanas
    JOptionPane.showMessageDialog(null,"Las ciudades mas alejadas son "+nombre_ciudades[iMayor]+ " Y " +nombre_ciudades[jMayor]);
    JOptionPane.showMessageDialog(null,"Las ciudades con menos distacias son "+nombre_ciudades[iMenor]+ " Y " +nombre_ciudades[jMenor]);
    
    // TODO code application logic here
      
    }
    
}
