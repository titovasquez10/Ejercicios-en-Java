/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package usc.algoritmos2.UI;

import java.awt.*;
import javax.swing.*;

/**
 *
 * @author desarrollo
 */
public class PanelImagen extends JPanel{
    
    
    public PanelImagen()
    {
       //Definir tamaño y diagrama:
    
       setPreferredSize(new Dimension(400, 600)); 
       setLayout(new BorderLayout());
       
       //Adicionar elementos de UI:
      
       //Adiccionar imagne:
       JLabel imagen = new JLabel();
       ImageIcon icono = new ImageIcon("./imagenes/logo.jpg");
       imagen = new JLabel("");
       imagen.setIcon(icono);
       
       
       //Adiccionar elemento:
       add(imagen, BorderLayout.NORTH); //Parte donde se colocara
       setBackground(Color.WHITE); //Color fondo
    }
    
}
