/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package usc.algoritmos2.modelo;

import java.io.*;
import java.util.*;

/**
 *
 * @author desarrollo
 */
public class ColeccionMusica {
    
   ArrayList<Grupo> grupos;
   
   public ColeccionMusica()
   {
     grupos = new ArrayList<Grupo>();
   }        
     
   
   
   public void AgregarGrupo(Grupo nuevoGrupo)
    {
     grupos.add(nuevoGrupo);        
    }
    
   
    
    public ArrayList<Grupo> darGrupos()
    {
        return grupos;
    }        
    
    
    public void CargarLista(String rutaArchivo)
    {
     try{
         BufferedReader br = new BufferedReader(new FileReader(rutaArchivo));
         
         int numGrupos = Integer.parseInt(br.readLine());
         for(int i =0; i< numGrupos; i++)
         {
            AgregarGrupo(new Grupo(br.readLine()));
         }
         
         br.close();
     } catch (FileNotFoundException e) {
        e.printStackTrace();
        
     } catch (IOException e){
          e.printStackTrace();
     }
        
        
    }        
    
    
    
  
   
    
}
