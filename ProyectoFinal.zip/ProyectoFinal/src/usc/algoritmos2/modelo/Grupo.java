/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package usc.algoritmos2.modelo;

/**
 *
 * @author desarrollo
 */
public class Grupo {
    
    String nombre;
    
    public Grupo(String unNombre)
    {
     unNombre = nombre;   
    }
    
    public String darNombre()
    {
        return nombre;
    }        
    
    
}
