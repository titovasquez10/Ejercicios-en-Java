/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Clases;

import Ventanas.Horarios;

/**
 *
 * @author MASTER
 */
public class AgregarMateria {
    
    
    
    public static void añadir() {
    String vardia=(String) Horarios.combodia.getSelectedItem();
    String varhora=(String) Horarios.combohora.getSelectedItem();
    String varmateria=(String) Horarios.txtmateria.getText();
        
        if("Lunes".equals(vardia)){
            if("07:00 - 10:00".equals(varhora)){
             Horarios.l1.setText(varmateria);
            }
            if("10:00 - 13:00".equals(varhora)){
             Horarios.l2.setText(varmateria);
            }
            if("14:00 - 17:00".equals(varhora)){
             Horarios.l3.setText(varmateria);
            }
            if("18:30 - 21:00".equals(varhora)){
             Horarios.l4.setText(varmateria);
            }
        }
        if("Martes".equals(vardia)){
            if("07:00 - 10:00".equals(varhora)){
             Horarios.ma1.setText(varmateria);
            }
            if("10:00 - 13:00".equals(varhora)){
             Horarios.ma2.setText(varmateria);
            }
            if("14:00 - 17:00".equals(varhora)){
             Horarios.ma3.setText(varmateria);
            }
            if("18:30 - 21:00".equals(varhora)){
             Horarios.ma4.setText(varmateria);
            }
        }
        if("Miercoles".equals(vardia)){
            if("07:00 - 10:00".equals(varhora)){
             Horarios.mi1.setText(varmateria);
            }
            if("10:00 - 13:00".equals(varhora)){
             Horarios.mi2.setText(varmateria);
            }
            if("14:00 - 17:00".equals(varhora)){
             Horarios.mi3.setText(varmateria);
            }
            if("18:30 - 21:00".equals(varhora)){
             Horarios.mi4.setText(varmateria);
            }
        }
        if("Jueves".equals(vardia)){
            if("07:00 - 10:00".equals(varhora)){
             Horarios.j1.setText(varmateria);
            }
            if("10:00 - 13:00".equals(varhora)){
             Horarios.j2.setText(varmateria);
            }
            if("14:00 - 17:00".equals(varhora)){
             Horarios.j3.setText(varmateria);
            }
            if("18:30 - 21:00".equals(varhora)){
             Horarios.j4.setText(varmateria);
            }
        }
        if("Viernes".equals(vardia)){
            if("07:00 - 10:00".equals(varhora)){
             Horarios.v1.setText(varmateria);
            }
            if("10:00 - 13:00".equals(varhora)){
             Horarios.v2.setText(varmateria);
            }
            if("14:00 - 17:00".equals(varhora)){
             Horarios.v3.setText(varmateria);
            }
            if("18:30 - 21:00".equals(varhora)){
             Horarios.v4.setText(varmateria);
            }
        }
        if("Sabado".equals(vardia)){
            if("07:00 - 10:00".equals(varhora)){
             Horarios.s1.setText(varmateria);
            }
            if("10:00 - 13:00".equals(varhora)){
             Horarios.s2.setText(varmateria);
            }
            if("14:00 - 17:00".equals(varhora)){
             Horarios.s3.setText(varmateria);
            }
            if("18:30 - 21:00".equals(varhora)){
             Horarios.s4.setText(varmateria);
            }
        }
        if("Domingo".equals(vardia)){
            if("07:00 - 10:00".equals(varhora)){
             Horarios.d1.setText(varmateria);
            }
            if("10:00 - 13:00".equals(varhora)){
             Horarios.d2.setText(varmateria);
            }
            if("14:00 - 17:00".equals(varhora)){
             Horarios.d3.setText(varmateria);
            }
            if("18:30 - 21:00".equals(varhora)){
             Horarios.d4.setText(varmateria);
            }
        }
    
     }
    
}
