/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Clases;

import Ventanas.Horarios;
import javax.swing.JComboBox;
import javax.swing.JOptionPane;

/**
 *
 * @author MASTER
 */
public class GenerarReportes {
    public static void reportes() {
        int contador1 = 0, contador2 = 0;
        String[] list = {"Seleccione dia...","Lunes", "Martes", "Miercoles", "Jueves", "Viernes", "Sabado", "Domingo"};
        JComboBox jcb = new JComboBox(list);
        jcb.setEditable(true);
       
        JOptionPane.showMessageDialog( null,jcb, "Seleccione dia a consultar cantidad materias...", JOptionPane.QUESTION_MESSAGE);
        String vardiaconsul=(String) jcb.getSelectedItem();
        Horarios.var1.setText(vardiaconsul);
        
        
        if("Lunes".equals(vardiaconsul)){
            if(!"".equals(Horarios.l1.getText())){
             contador1=contador1+1;
            }
            if(!"".equals(Horarios.l2.getText())){
             contador1=contador1+1;
            }
            if(!"".equals(Horarios.l3.getText())){
             contador1=contador1+1;
            }
            if(!"".equals(Horarios.l4.getText())){
             contador1=contador1+1;
            }
        }
        
        if("Martes".equals(vardiaconsul)){
            if(!"".equals(Horarios.ma1.getText())){
             contador1=contador1+1;
            }
            if(!"".equals(Horarios.ma2.getText())){
             contador1=contador1+1;
            }
            if(!"".equals(Horarios.ma3.getText())){
             contador1=contador1+1;
            }
            if(!"".equals(Horarios.ma4.getText())){
             contador1=contador1+1;
            }
        }
        
        if("Miercoles".equals(vardiaconsul)){
            if(!"".equals(Horarios.mi1.getText())){
             contador1=contador1+1;
            }
            if(!"".equals(Horarios.mi2.getText())){
             contador1=contador1+1;
            }
            if(!"".equals(Horarios.mi3.getText())){
             contador1=contador1+1;
            }
            if(!"".equals(Horarios.mi4.getText())){
             contador1=contador1+1;
            }
        }
        if("Jueves".equals(vardiaconsul)){
            if(!"".equals(Horarios.j1.getText())){
             contador1=contador1+1;
            }
            if(!"".equals(Horarios.j2.getText())){
             contador1=contador1+1;
            }
            if(!"".equals(Horarios.j3.getText())){
             contador1=contador1+1;
            }
            if(!"".equals(Horarios.j4.getText())){
             contador1=contador1+1;
            }
        }
        if("Viernes".equals(vardiaconsul)){
            if(!"".equals(Horarios.v1.getText())){
             contador1=contador1+1;
            }
            if(!"".equals(Horarios.v2.getText())){
             contador1=contador1+1;
            }
            if(!"".equals(Horarios.v3.getText())){
             contador1=contador1+1;
            }
            if(!"".equals(Horarios.v4.getText())){
             contador1=contador1+1;
            }
        }
        if("Sabado".equals(vardiaconsul)){
            if(!"".equals(Horarios.s1.getText())){
             contador1=contador1+1;
            }
            if(!"".equals(Horarios.s2.getText())){
             contador1=contador1+1;
            }
            if(!"".equals(Horarios.s3.getText())){
             contador1=contador1+1;
            }
            if(!"".equals(Horarios.s4.getText())){
             contador1=contador1+1;
            }
        }
        if("Domingo".equals(vardiaconsul)){
            if(!"".equals(Horarios.d1.getText())){
             contador1=contador1+1;
            }
            if(!"".equals(Horarios.d2.getText())){
             contador1=contador1+1;
            }
            if(!"".equals(Horarios.d3.getText())){
             contador1=contador1+1;
            }
            if(!"".equals(Horarios.d4.getText())){
             contador1=contador1+1;
            }
        }
        
        
        
        
        
        String[] list1 = {"Seleccione hora..","07:00 - 10:00", "10:00 - 13:00", "14:00 - 17:00", "18:30 - 21:00"};
        JComboBox jcb1 = new JComboBox(list1);
        jcb1.setEditable(true);
       
        JOptionPane.showMessageDialog( null,jcb1, "Seleccione hora a consultar cantidad materias...", JOptionPane.QUESTION_MESSAGE);
        String vardiaconsul1=(String) jcb1.getSelectedItem();
        Horarios.var2.setText(vardiaconsul1);
        
        if("07:00 - 10:00".equals(vardiaconsul1)){
            if(!"".equals(Horarios.l1.getText())){
             contador2=contador2+1;
            }
            if(!"".equals(Horarios.ma1.getText())){
             contador2=contador2+1;
            }
            if(!"".equals(Horarios.mi1.getText())){
             contador2=contador2+1;
            }
            if(!"".equals(Horarios.j1.getText())){
             contador2=contador2+1;
            }
            if(!"".equals(Horarios.v1.getText())){
             contador2=contador2+1;
            }
            if(!"".equals(Horarios.s1.getText())){
             contador2=contador2+1;
            }
            if(!"".equals(Horarios.d1.getText())){
             contador2=contador2+1;
            }
        }
        
        if("10:00 - 13:00".equals(vardiaconsul1)){
            if(!"".equals(Horarios.l2.getText())){
             contador2=contador2+1;
            }
            if(!"".equals(Horarios.ma2.getText())){
             contador2=contador2+1;
            }
            if(!"".equals(Horarios.mi2.getText())){
             contador2=contador2+1;
            }
            if(!"".equals(Horarios.j2.getText())){
             contador2=contador2+1;
            }
            if(!"".equals(Horarios.v2.getText())){
             contador2=contador2+1;
            }
            if(!"".equals(Horarios.s2.getText())){
             contador2=contador2+1;
            }
            if(!"".equals(Horarios.d2.getText())){
             contador2=contador2+1;
            }
        }
        if("14:00 - 17:00".equals(vardiaconsul1)){
            if(!"".equals(Horarios.l3.getText())){
             contador2=contador2+1;
            }
            if(!"".equals(Horarios.ma3.getText())){
             contador2=contador2+1;
            }
            if(!"".equals(Horarios.mi3.getText())){
             contador2=contador2+1;
            }
            if(!"".equals(Horarios.j3.getText())){
             contador2=contador2+1;
            }
            if(!"".equals(Horarios.v3.getText())){
             contador2=contador2+1;
            }
            if(!"".equals(Horarios.s3.getText())){
             contador2=contador2+1;
            }
            if(!"".equals(Horarios.d3.getText())){
             contador2=contador2+1;
            }
        }
        if("18:30 - 21:00".equals(vardiaconsul1)){
            if(!"".equals(Horarios.l4.getText())){
             contador2=contador2+1;
            }
            if(!"".equals(Horarios.ma4.getText())){
             contador2=contador2+1;
            }
            if(!"".equals(Horarios.mi4.getText())){
             contador2=contador2+1;
            }
            if(!"".equals(Horarios.j4.getText())){
             contador2=contador2+1;
            }
            if(!"".equals(Horarios.v4.getText())){
             contador2=contador2+1;
            }
            if(!"".equals(Horarios.s4.getText())){
             contador2=contador2+1;
            }
            if(!"".equals(Horarios.d4.getText())){
             contador2=contador2+1;
            }
        }
        
        
        
        
        
        
        
        
        
        int contadortotal=0;
        int contadorLUNES=0;
        int contadorMARTES=0;
        int contadorMIERCOLES=0;
        int contadorJUEVES=0;
        int contadorVIERNES=0;
        int contadorSABADO=0;
        int contadorDOMINGO=0;
                
        
        
            if(!"".equals(Horarios.l1.getText())){
             contadorLUNES=contadorLUNES+1;
            }
            if(!"".equals(Horarios.l2.getText())){
             contadorLUNES=contadorLUNES+1;
            }
            if(!"".equals(Horarios.l3.getText())){
             contadorLUNES=contadorLUNES+1;
            }
            if(!"".equals(Horarios.l4.getText())){
             contadorLUNES=contadorLUNES+1;
            }
        
            if(!"".equals(Horarios.ma1.getText())){
             contadorMARTES=contadorMARTES+1;
            }
            if(!"".equals(Horarios.ma2.getText())){
             contadorMARTES=contadorMARTES+1;
            }
            if(!"".equals(Horarios.ma3.getText())){
             contadorMARTES=contadorMARTES+1;
            }
            if(!"".equals(Horarios.ma4.getText())){
             contadorMARTES=contadorMARTES+1;
            }
        
            if(!"".equals(Horarios.mi1.getText())){
             contadorMIERCOLES=contadorMIERCOLES+1;
            }
            if(!"".equals(Horarios.mi2.getText())){
             contadorMIERCOLES=contadorMIERCOLES+1;
            }
            if(!"".equals(Horarios.mi3.getText())){
             contadorMIERCOLES=contadorMIERCOLES+1;
            }
            if(!"".equals(Horarios.mi4.getText())){
             contadorMIERCOLES=contadorMIERCOLES+1;
            }
        
            if(!"".equals(Horarios.j1.getText())){
             contadorJUEVES=contadorJUEVES+1;
            }
            if(!"".equals(Horarios.j2.getText())){
             contadorJUEVES=contadorJUEVES+1;
            }
            if(!"".equals(Horarios.j3.getText())){
             contadorJUEVES=contadorJUEVES+1;
            }
            if(!"".equals(Horarios.j4.getText())){
             contadorJUEVES=contadorJUEVES+1;
            }
        
            if(!"".equals(Horarios.v1.getText())){
             contadorVIERNES=contadorVIERNES+1;
            }
            if(!"".equals(Horarios.v2.getText())){
             contadorVIERNES=contadorVIERNES+1;
            }
            if(!"".equals(Horarios.v3.getText())){
             contadorVIERNES=contadorVIERNES+1;
            }
            if(!"".equals(Horarios.v4.getText())){
             contadorVIERNES=contadorVIERNES+1;
            }
        
            if(!"".equals(Horarios.s1.getText())){
             contadorSABADO=contadorSABADO+1;
            }
            if(!"".equals(Horarios.s2.getText())){
             contadorSABADO=contadorSABADO+1;
            }
            if(!"".equals(Horarios.s3.getText())){
             contadorSABADO=contadorSABADO+1;
            }
            if(!"".equals(Horarios.s4.getText())){
             contadorSABADO=contadorSABADO+1;
            }
        
            if(!"".equals(Horarios.d1.getText())){
             contadorDOMINGO=contadorDOMINGO+1;
            }
            if(!"".equals(Horarios.d2.getText())){
             contadorDOMINGO=contadorDOMINGO+1;
            }
            if(!"".equals(Horarios.d3.getText())){
             contadorDOMINGO=contadorDOMINGO+1;
            }
            if(!"".equals(Horarios.d4.getText())){
             contadorDOMINGO=contadorDOMINGO+1;
            }
            
            
            int[] valores = new int[7]; // Esto es una lista de 5 elementos
      valores[0] = contadorLUNES;            // Y aqui vamos introduciendo
      valores[1] = contadorMARTES;            // los elementos de la lista
      valores[2] = contadorMIERCOLES;             // 
      valores[3] = contadorJUEVES;            // El numero de dentro del corchete
      valores[4] = contadorVIERNES;  
      valores[5] = contadorSABADO;            // El numero de dentro del corchete
      valores[6] = contadorDOMINGO;          // es el indice del array

      int min = valores[0];
      int max = valores[0];  

      for (int i = 1; i < 7; i++) {  
          if (valores[i] < min) {  
              min = valores[i]; 
          } else if (valores[i] > max) {
              max = valores[i]; 
          }
      }

      if(max==contadorLUNES){
        Horarios.cont4.setText("LUNES");  
      }
      if(max==contadorMARTES){
        Horarios.cont4.setText("MARTES");  
      }
      if(max==contadorMIERCOLES){
        Horarios.cont4.setText("MIERCOLES");  
      }
      if(max==contadorJUEVES){
        Horarios.cont4.setText("JUEVES");  
      }
      if(max==contadorVIERNES){
        Horarios.cont4.setText("VIERNES");  
      }
      if(max==contadorSABADO){
        Horarios.cont4.setText("SABADO");  
      }
      if(max==contadorDOMINGO){
        Horarios.cont4.setText("DOMINGO");  
      }
      
            String nombre= Horarios.txtnom.getText();
            Horarios.txtnom2.setText(nombre);
            contadortotal=contadorLUNES+contadorMARTES+contadorMIERCOLES+contadorJUEVES+contadorVIERNES+contadorSABADO+contadorDOMINGO;
            Horarios.cont3.setText(contadortotal+"");
            Horarios.cont1.setText(contador1+"");
            Horarios.cont2.setText(contador2+"");
        
        
        
    }
   
    
    
}
